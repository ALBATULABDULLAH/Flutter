import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  void submitData() {
    // Function to submit data
    print('Data submitted');
  }

  void cancelAction() {
    // Function to cancel action
    //  print('Action canceled');
  }
  void navigateToScreen() {
    // Function to navigate to another screen
    print('Navigate to another screen');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Flutter App'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.symmetric(vertical: 10),
              child: Text(
                'Welcome to my Flutter App!',
                style: TextStyle(fontSize: 20),
              ),
            ),
            ElevatedButton(
              onPressed: submitData,
              child: Text('Submit'),
            ),
            OutlinedButton(
              onPressed: cancelAction,
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: navigateToScreen,
              child: Text('Navigate'),
            ),
          ],
        ),
      ),
    );
  }
}
